function setup() {
  let p5canvas = createCanvas(800, 600);
  p5canvas.parent("tamagotchi");
  frameRate(30);
  }

new p5();
var width = 800;
var height = 600;
